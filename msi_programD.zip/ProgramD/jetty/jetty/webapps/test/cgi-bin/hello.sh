#!/bin/sh
echo "Content-Type: text/html"
echo
echo "<H1>Hello World</H1>"
