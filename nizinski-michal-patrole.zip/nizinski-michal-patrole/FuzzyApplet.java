import javax.swing.JApplet;
import javax.swing.SwingUtilities;

public class FuzzyApplet extends JApplet {

  private static final long serialVersionUID = 1L;

  public void init() {
      try {
          SwingUtilities.invokeAndWait(new Runnable() {
              public void run() {
                  createGUI();
              }
          });
      } catch (Exception e) { 
          System.err.println("createGUI didn't complete successfully");
      }
  }
  
  private void createGUI() {
      //Create and set up the content pane.
      FuzzyPanel newContentPane = new FuzzyPanel();
      newContentPane.setOpaque(true); 
      setContentPane(newContentPane);        
  }       
}
