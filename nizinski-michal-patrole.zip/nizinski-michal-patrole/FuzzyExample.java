import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.rule.FuzzyRuleSet;

public class FuzzyExample {

  public static void main(String[] args) throws Exception {
    try {
      String fileName = args[0];
      int liczbaPatroli = Integer.parseInt(args[1]);
      int poraDnia = Integer.parseInt(args[2]);
      int imprezyMasowe = Integer.parseInt(args[3]);
      int liczbaZgloszen = Integer.parseInt(args[4]);
      FIS fis = FIS.load(fileName, false);

      //wyswietl wykresy funkcji fuzyfikacji i defuzyfikacji
      FuzzyRuleSet fuzzyRuleSet = fis.getFuzzyRuleSet();
      fuzzyRuleSet.chart();

      //zadaj wartosci wejsciowe
      fuzzyRuleSet.setVariable("liczba_patroli", liczbaPatroli);
      fuzzyRuleSet.setVariable("pora_dnia", poraDnia);
      fuzzyRuleSet.setVariable("imprezy_masowe", imprezyMasowe);
      fuzzyRuleSet.setVariable("liczba_zgloszen", liczbaZgloszen);
      //logika sterownika
      fuzzyRuleSet.evaluate();

      //graficzna prezentacja wyjscia
      fuzzyRuleSet.getVariable("zmiana_patroli").chartDefuzzifier(true);

      //System.out.println(fuzzyRuleSet);

    } catch (ArrayIndexOutOfBoundsException ex) {
      System.out.println("Niepoprawna liczba parametrow. Przyklad: java FuzzyExample string<plik_fcl> int<liczba patroli> int<pora dnia> int<imprezy masowe> int<liczba zgloszen>");
    } catch (NumberFormatException ex) {
      System.out.println("Niepoprawny parametr. Przyklad: java FuzzyExample string<plik_fcl> int<liczba patroli> int<pora dnia> int<imprezy masowe> int<liczba zgloszen>");
    } catch (Exception ex) {
      System.out.println(ex.toString());
    }
  }

}