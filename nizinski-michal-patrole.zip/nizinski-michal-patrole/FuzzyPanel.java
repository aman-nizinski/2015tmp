import java.awt.BorderLayout;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.rule.FuzzyRuleSet;

public class FuzzyPanel extends JPanel implements Runnable {

  private static final long serialVersionUID = 1L;
  
  private static final String FCL = "FUNCTION_BLOCK\r\n" + 
  		"\r\n" + 
  		"VAR_INPUT\r\n" + 
  		"liczba_patroli : REAL;\r\n" + 
  		"pora_dnia : REAL;\r\n" + 
  		"imprezy_masowe : REAL;\r\n" + 
  		"liczba_zgloszen : REAL;\r\n" + 
  		"END_VAR\r\n" + 
  		"\r\n" + 
  		"VAR_OUTPUT\r\n" + 
  		"zmiana_patroli : REAL;\r\n" + 
  		"END_VAR\r\n" + 
  		"\r\n" + 
  		"FUZZIFY liczba_patroli\r\n" + 
  		"TERM bardzoMalo := (1, 1) (2, 1) (5, 0.50) (8, 0);\r\n" + 
  		"TERM malo := (2, 0) (4, 0.50) (6, 1) (9, 1) (11, 0.50) (15, 0);\r\n" + 
  		"TERM duzo := (10, 0) (12, 0.50) (15, 1) (16, 1) (19, 0.50) (21, 0);\r\n" + 
  		"TERM bardzoDuzo := (15, 0) (20, 0.50) (22, 1) (30, 1);\r\n" + 
  		"END_FUZZIFY\r\n" + 
  		"\r\n" + 
  		"FUZZIFY pora_dnia\r\n" + 
  		"TERM ranek := (1, 0) (3, 0.50) (5, 1) (7, 1) (9, 0.50) (11, 0);\r\n" + 
  		"TERM poludnie := (7, 0) (9, 0.50) (11, 1) (13, 1) (15, 0.50) (17, 0);\r\n" + 
  		"TERM wieczor := (13, 0) (15, 0.50) (17, 1) (19, 1) (21, 0.50) (23, 0);\r\n" + 
  		"TERM noc := (0,1) (1, 1) (3, 0.50) (5, 0) (19, 0) (21, 0.50) (23, 1);\r\n" + 
  		"END_FUZZIFY\r\n" + 
  		"\r\n" + 
  		"FUZZIFY imprezy_masowe\r\n" + 
  		"TERM nicSieNieDzieje := (0, 1) (2, 0.5) (4, 0);\r\n" + 
  		"TERM jestJakisKoncert := (0, 0) (1, 0.50) (2, 1) (3, 0.5) (4, 0);\r\n" + 
  		"TERM jestWaznyMecz := (2, 0) (4, 0.50) (6, 1) (7, 0.5) (8, 0);\r\n" + 
  		"TERM saJuwenalia := (5, 0) (7, 0.50) (8, 1) (10, 1);\r\n" + 
  		"END_FUZZIFY\r\n" + 
  		"\r\n" + 
  		"FUZZIFY liczba_zgloszen\r\n" + 
  		"TERM mala := (0, 1) (2, 1) (4, 0.5) (6, 0);\r\n" + 
  		"TERM srednia := (2, 0) (3, 0.50) (5, 1) (7, 0.5) (9, 0);\r\n" + 
  		"TERM duza := (4, 0) (6, 0.50) (8, 1) (10, 1);\r\n" + 
  		"END_FUZZIFY\r\n" + 
  		"\r\n" + 
  		"DEFUZZIFY zmiana_patroli\r\n" + 
  		"TERM zmniejsz := (-3, 1) (-2, 1) (-1, 0.5) (0, 0);\r\n" + 
  		"TERM zostaw := (-2, 0) (-1, 0.50) (0, 1) (1, 0.5) (2, 0);\r\n" + 
  		"TERM zwieksz := (0, 0) (1, 0.50) (2, 1) (3, 1);\r\n" + 
  		"METHOD : COG;\r\n" + 
  		"DEFAULT := 0;\r\n" + 
  		"END_DEFUZZIFY\r\n" + 
  		"\r\n" + 
  		"RULEBLOCK first\r\n" + 
  		"AND: MIN;\r\n" + 
  		"ACT: MIN;\r\n" + 
  		"\r\n" + 
  		"RULE 0: IF liczba_patroli IS bardzoMalo OR pora_dnia IS wieczor THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"RULE 1: IF liczba_patroli IS bardzoDuzo OR pora_dnia IS ranek THEN zmiana_patroli IS zmniejsz;\r\n" + 
  		"RULE 2: IF liczba_patroli IS malo OR liczba_patroli IS duzo THEN zmiana_patroli IS zostaw;\r\n" + 
  		"RULE 3: IF pora_dnia IS poludnie OR pora_dnia IS noc THEN zmiana_patroli IS zmniejsz;\r\n" + 
  		"\r\n" + 
  		"RULE 4: IF liczba_patroli IS bardzoDuzo AND imprezy_masowe IS nicSieNieDzieje THEN zmiana_patroli IS zmniejsz;\r\n" + 
  		"RULE 5: IF liczba_patroli IS duzo AND imprezy_masowe IS nicSieNieDzieje THEN zmiana_patroli IS zmniejsz;\r\n" + 
  		"RULE 6: IF liczba_patroli IS malo AND imprezy_masowe IS jestJakisKoncert THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"RULE 7: IF imprezy_masowe IS jestWaznyMecz THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"RULE 8: IF imprezy_masowe IS saJuwenalia THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"\r\n" + 
  		"RULE 9: IF liczba_patroli is bardzoMalo AND liczba_zgloszen IS mala THEN zmiana_patroli IS zostaw;\r\n" + 
  		"RULE 10: IF liczba_patroli is malo AND liczba_zgloszen IS mala THEN zmiana_patroli IS zostaw;\r\n" + 
  		"RULE 11: IF liczba_patroli is duzo AND liczba_zgloszen IS mala THEN zmiana_patroli IS zmniejsz;\r\n" + 
  		"RULE 12: IF liczba_patroli is bardzoDuzo AND liczba_zgloszen IS mala THEN zmiana_patroli IS zmniejsz;\r\n" + 
  		"RULE 13: IF liczba_patroli is bardzoMalo AND liczba_zgloszen IS srednia THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"RULE 14: IF liczba_patroli is malo AND liczba_zgloszen IS srednia THEN zmiana_patroli IS zostaw;\r\n" + 
  		"RULE 15: IF liczba_patroli is duzo AND liczba_zgloszen IS srednia THEN zmiana_patroli IS zostaw;\r\n" + 
  		"RULE 16: IF liczba_patroli is bardzoDuzo AND liczba_zgloszen IS srednia THEN zmiana_patroli IS zmniejsz;\r\n" + 
  		"RULE 17: IF liczba_patroli is bardzoMalo AND liczba_zgloszen IS duza THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"RULE 18: IF liczba_patroli is malo AND liczba_zgloszen IS duza THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"RULE 19: IF liczba_patroli is duzo AND liczba_zgloszen IS duza THEN zmiana_patroli IS zwieksz;\r\n" + 
  		"RULE 20: IF liczba_patroli is bardzoDuzo AND liczba_zgloszen IS duza THEN zmiana_patroli IS zostaw;\r\n" + 
  		"END_RULEBLOCK\r\n" + 
  		"\r\n" + 
  		"END_FUNCTION_BLOCK\r\n";
  
  private static final String[] DATA_STRING = {"godzina", "imprezy", "zgloszenia", "patrole"};
  private int[] data_value;
  private int imprezy_mod;
  private boolean imprezy_up;
  private boolean zgloszenia_up;
  private FIS fis;

  private DefaultCategoryDataset dataset;
  
  public FuzzyPanel() {
    super(new BorderLayout());
    data_value = new int[]{0, 1, 1, 15};
    dataset = new DefaultCategoryDataset();
    imprezy_mod = 0;
    imprezy_up = true;
    zgloszenia_up = true;
    for(int i = 0; i < 4; ++i) {
      dataset.addValue(data_value[i], DATA_STRING[i], DATA_STRING[i]);
    }
    JFreeChart chart = ChartFactory.createBarChart(
        null,
        null, 
        null,
        dataset, PlotOrientation.VERTICAL
        , false, false, false
        );
    ValueAxis xaxis = chart.getCategoryPlot().getRangeAxis();
    xaxis.setLowerBound(0);
    xaxis.setUpperBound(30);
    add(new ChartPanel(chart));
    new Thread(this).start();
  }

  @Override
  public void run() {
    try {
      fis = FIS.createFromString(FCL, false);
      FuzzyRuleSet fuzzyRuleSet = fis.getFuzzyRuleSet();
      while(true) {
          Thread.sleep(500);
          data_value[0] = (data_value[0] + 1) % 24;
          imprezy_mod = (imprezy_mod + 1) % 10;
          if(imprezy_mod == 0) {
            if(imprezy_up) {
              if(data_value[1] < 9) {
                ++data_value[1];
              } else {
                --data_value[1];
                imprezy_up = false;
              }
            } else {
              if(data_value[1] > 1) {
                --data_value[1];
              } else {
                ++data_value[1];
                imprezy_up = true;
              }
            }
          }
          if(zgloszenia_up) {
            if(data_value[2] < 9) {
              ++data_value[2];
            } else {
              --data_value[2];
              zgloszenia_up = false;
            }
          } else {
            if(data_value[2] > 1) {
              --data_value[2];
            } else {
              ++data_value[2];
              zgloszenia_up = true;
            }
          }
          fuzzyRuleSet.setVariable("liczba_patroli", data_value[3]);
          fuzzyRuleSet.setVariable("pora_dnia", data_value[0]);
          fuzzyRuleSet.setVariable("imprezy_masowe", data_value[1]);
          fuzzyRuleSet.setVariable("liczba_zgloszen", data_value[2]);
          fuzzyRuleSet.evaluate();
          data_value[3] += (int) Math.round(fuzzyRuleSet.getVariable("zmiana_patroli").getLatestDefuzzifiedValue());
          for(int i = 0; i < 4; ++i) {
            dataset.setValue(data_value[i], DATA_STRING[i], DATA_STRING[i]);
          }
      }
  } catch (Exception ex) {
      ex.printStackTrace();
  }
  }

  
}
